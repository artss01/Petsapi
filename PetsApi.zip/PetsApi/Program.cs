using Microsoft.EntityFrameworkCore; 
using PetsApi.Data; 
using PetsApi.Models; 
  
var builder = WebApplication.CreateBuilder(args); 
  
// Adicionando o contexto do Entity Framework com banco de dados em memória 
builder.Services.AddDbContext<AnimalContext>(options => 
	options.UseInMemoryDatabase("AnimalDB")); 
  
// Adicionando o Swagger para autodocumentação 
builder.Services.AddEndpointsApiExplorer(); 
builder.Services.AddSwaggerGen(); 
  
var app = builder.Build(); 
  
// Ativando o Swagger 
if (app.Environment.IsDevelopment()) 
{ 
	app.UseSwagger(); 
	app.UseSwaggerUI(); 
} 
  
app.UseHttpsRedirection(); 
  
// GET - Obter todos os animais 
app.MapGet("/animals", async (AnimalContext db) => 
	await db.Animais.ToListAsync()); 
  
// GET - Obter animal por ID 
app.MapGet("/animals/{id}", async (int id, AnimalContext db) => 
	await db.Animais.FindAsync(id) is Animal animal 
    	? Results.Ok(animal) 
    	: Results.NotFound()); 
  
// POST - Adicionar um novo animal 
app.MapPost("/animals", async (Animal animal, AnimalContext db) => 
{ 
	db.Animais.Add(animal); 
	await db.SaveChangesAsync(); 
	return Results.Created($"/animals/{animal.Id}", animal); 
}); 
  
// PUT - Atualizar um animal existente 
app.MapPut("/animals/{id}", async (int id, Animal inputAnimal, AnimalContext db) => 
{ 
	var animal = await db.Animais.FindAsync(id); 
  
	if (animal is null) return Results.NotFound(); 
  
	animal.Nome = inputAnimal.Nome; 
	animal.Idade = inputAnimal.Idade; 
	animal.Cor = inputAnimal.Cor; 
	animal.Tipo = inputAnimal.Tipo; 
	animal.Peso = inputAnimal.Peso; 
    animal.Vacinado = inputAnimal.Vacinado;
  
	await db.SaveChangesAsync(); 
  
	return Results.NoContent(); 
}); 
  
// DELETE - Excluir um animal 
app.MapDelete("/animals/{id}", async (int id, AnimalContext db) => 
{ 
	var animal = await db.Animais.FindAsync(id); 
  
	if (animal is null) return Results.NotFound(); 
  
	db.Animais.Remove(animal); 
	await db.SaveChangesAsync(); 
  
	return Results.Ok(animal); 
}); 
  
app.Run();
