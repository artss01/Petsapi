namespace PetsApi.Models
{
    public class Animal
    {
        public int Id {get; set; }
        public string Nome {get; set;}
        public int Idade{get; set;}    
        public string Cor{get; set;}
        public string Tipo{get; set;}
        public float Peso{get; set;}
        public bool Vacinado { get; set; }
    }
}